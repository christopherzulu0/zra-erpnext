# Copyright (c) 2025, Brian Mwambia and contributors
# For license information, please see license.txt

# import frappe
from frappe.model.document import Document


class CrystallisedSmartReasonForValueCreditNote(Document):
	pass
